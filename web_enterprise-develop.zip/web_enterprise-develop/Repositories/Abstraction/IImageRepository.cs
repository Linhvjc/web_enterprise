﻿
using WebEnterprise.Repositories.Implement;
using WebEnterprise.Models.Entities;
namespace WebEnterprise.Repositories.Abstraction
{
    public interface IImageRepository : IGenericRepository<Image>
    {
    }
}
