﻿ namespace WebEnterprise.ViewModels.Faculty
{
    public class GetFacultyModel
    {
        public int FacultyId { get; set; }
        public string Name { get; set; }
    }
}
