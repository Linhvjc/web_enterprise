﻿namespace WebEnterprise.ViewModels.Contribution
{
    public class ListContributionStudent
    {
        public List<GetContributionStudent> GetContributionStudents { get; set; } = new List<GetContributionStudent>();
        public UpdateContribution UpdateContribution { get; set; }
    }
}
