﻿namespace WebEnterprise.ViewModels.Contribution
{
    public class ContributionList
    {
        public List<GetContributionModel> Contributions { get; set; }
    }
}
