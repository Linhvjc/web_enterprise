﻿namespace WebEnterprise.ViewModels.Contribution
{
    public class GetContributionStudent
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string MegazineName { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
